create function pg_catalog.age(timestamp with time zone) returns interval
LANGUAGE SQL
AS $$
select pg_catalog.age(cast(current_date as timestamp with time zone), $1)
$$;
